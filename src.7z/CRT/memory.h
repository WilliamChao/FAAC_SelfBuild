#ifndef memory_h
#define memory_h
#include "size_t.h"

void* memset(void *ptr, int value, size_t num);
void * memcpy ( void * destination, const void * source, size_t num );
size_t strlen ( const char * str );

#endif // memory_h
