#ifndef assert_h
#define assert_h

#define assert(...)

#endif // assert_h
