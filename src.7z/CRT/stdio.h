#ifndef stdio_h
#define stdio_h
#include "size_t.h"

int sprintf ( char * str, const char * format, ... );

struct FILE;
typedef struct FILE FILE;
FILE *stdin, *stdout, *stderr;

FILE * fopen ( const char * filename, const char * mode );
int fclose ( FILE * stream );
int fprintf ( FILE * stream, const char * format, ... );

#endif // stdio_h
