#ifndef stdlib_h
#define stdlib_h
#include "size_t.h"

#define NULL 0

void* malloc(size_t size);
void free(void *ptr);
void exit (int status);

#endif // stdlib_h
