#ifndef math_h
#define math_h

double sin(double x);
double cos (double x);
double asin(double x);
double log (double x);
double log10 (double x);
double fabs (double x);
double pow (double base, double exponent);
double sqrt (double x);

#endif // math_h
